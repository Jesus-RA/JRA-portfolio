@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4 mx-auto">
                @include('components.modal-project')
            </div>
        </div>
    </div>
@endsection
