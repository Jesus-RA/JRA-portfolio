<?php $__env->startSection('content'); ?>
    <div class="hero-image">
        <div class="d-flex align-items-center h-100">
            <div class="col-12 col-md-7 offset-md-1">
                <span class="d-block mb-1 text-md-left ml-2 ml-md-0"> <strong>Hello, my name is</strong> </span>
                <h1 class="name text-md-left text-center">Jesús Ramírez Alejandro</h1>
                <h3 class="name mb-4 text-md-left text-center">I am a Web Developer</h3>
                <p class="col-md-8 col-xl-6 text-justify pl-md-0 mt-5 mb-4 mb-md-3">
                    Look at my work and get convince yourself you finally found you was looking for!
                </p>
                <a href="/#portfolio" class="btn btn-outline-light col-10 offset-1 offset-md-0 col-md-6 col-xl-4">Check my work!</a>
            </div>
        </div>
        
    </div>
    <div class="container">
        <section id="about" class="pt-3">
            <?php echo $__env->make('about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
        </section>

        <section id="portfolio" class="pt-3">
            <?php if(count($projects) > 0): ?>
                <?php echo $__env->make('portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </section>

        <section id="contact" class="">
            <contact></contact>
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/welcome.blade.php ENDPATH**/ ?>