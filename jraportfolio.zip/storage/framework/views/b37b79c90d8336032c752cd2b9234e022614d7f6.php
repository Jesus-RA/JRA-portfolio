<?php $__env->startSection('portfolio'); ?>
    <div class="alert alert-danger">Hola</div>
    <div class="row py-4">
        <?php if(empty($projects)): ?>
            <div class="alert alert-dark text-center col-md-6">
                There is no projects yet.
            </div>
        <?php else: ?>            
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-12 col-md-4 mb-3">
                    <?php echo $__env->make('components.project', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/test.blade.php ENDPATH**/ ?>