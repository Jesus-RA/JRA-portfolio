<div class="card text-white myProject mb-3">

    <div id="carousel<?php echo e($project->id); ?>" class="carousel slide carousel-fade hover touch" data-ride="carousel">
        <div class="carousel-inner">
            <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>" data-interval="3500">
                    <img 
                        src="<?php echo e(Storage::url($image->path)); ?>"
                        alt=""
                        class="d-block w-100 card-img-top projectImage"
                        height="200"
                    >                
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(auth()->user()): ?>
            <a href="#carousel<?php echo e($project->id); ?>" class="carousel-control-prev" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a href="#carousel<?php echo e($project->id); ?>" class="carousel-control-next" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        <?php endif; ?>
    </div>

    <div class="card-body">
        <h3 class="card-title text-center font-weight-bold"><?php echo e($project->name); ?></h3>
        <button type="button" class="btn btn-outline-light btn-block py-1" data-toggle="modal" data-target="#exampleModal<?php echo e($project->id); ?>">
            See project
        </button>
    </div>
</div><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/components/card-project.blade.php ENDPATH**/ ?>