
<?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/auth/register.blade.php ENDPATH**/ ?>