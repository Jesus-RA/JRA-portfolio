<?php echo e($slot); ?>

<?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>