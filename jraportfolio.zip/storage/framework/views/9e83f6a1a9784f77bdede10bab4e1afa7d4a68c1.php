<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card-body">
                    <div class="list-group">
                        <a href="<?php echo e(route('projects.index')); ?>" class="list-group-item bg-dark text-white mb-1">Manage Projects</a>
                        <a href="<?php echo e(route('technologies.index')); ?>" class="list-group-item bg-dark text-white mb-1">Manage technologies</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/panel.blade.php ENDPATH**/ ?>