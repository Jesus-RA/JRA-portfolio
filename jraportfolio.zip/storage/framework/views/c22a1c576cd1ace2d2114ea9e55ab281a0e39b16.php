<footer class="footer shadow-lg">
    <div class="container py-3">
        <div class="row justify-content-between align-items-center">
            <div class="col-md-3 text-center ">
                <a href="https://www.linkedin.com/in/jesúsra" target="_blank" class="flaticon-linkedin mx-2 icon"></a>
                <a href="https://github.com/Jesus-RA" target="_blank" class="flaticon-github mx-2 icon"></a>
            </div>

            <div class="col-md-4 author">
                <p class="text-center text-md-right mt-3 mt-md-2">
                    Copyright 2020 © JesúsRA
                    <span class="d-block small">Created by JesúsRA</span>
                </p>
            </div>
        </div>
    </div>
</footer><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/components/footer.blade.php ENDPATH**/ ?>