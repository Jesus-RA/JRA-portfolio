<?php echo e($slot); ?>

<?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>