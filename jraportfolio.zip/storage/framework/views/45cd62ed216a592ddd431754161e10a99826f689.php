<?php $__env->startSection('content'); ?>
    <div id="home">
        hola
    </div>
<?php $__env->stopSection(); ?>

<style>
    #id{
        background-image: url('https://images.unsplash.com/photo-1510519138101-570d1dca3d66?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1631&q=80')
        height: 100vh;
    }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/home.blade.php ENDPATH**/ ?>