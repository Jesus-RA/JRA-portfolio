<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <?php if( count($technologies) <= 0 ): ?>
            <div class="alert alert-danger text-center col-sm-8 col-md-6 mx-auto">
                There is no technologies yet!
            </div>
            <a href="<?php echo e(route('technologies.create')); ?>" class="btn btn-link btn-block mb-3">Create the first one</a>

        <?php else: ?>
            <div class="col-md-8 mx-auto">
                <a href="<?php echo e(route('technologies.create')); ?>" class="btn btn-dark border border-secondary mb-3">Add Technology</a>
                <table class="table text-white text-center table-hover table-dark ">
                    <thead>
                        <th>id</th>
                        <th>Icon</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($technology->id); ?></td>
                                <td>
                                    <img src="<?php echo e(Storage::url($technology->icon->path)); ?>" alt="technology<?php echo e($technology->name); ?>" width="100">
                                </td>
                                <td><?php echo e($technology->name); ?></td>
                                <td>
                                    <a
                                        href="<?php echo e(route('technologies.edit', $technology)); ?>"
                                        class="btn btn-warning"
                                    >Edit</a>
                                    <delete-technology
                                        technology="<?php echo e($technology->id); ?>"
                                        name="<?php echo e($technology->name); ?>"
                                    ></delete-technology>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/technologies/index.blade.php ENDPATH**/ ?>