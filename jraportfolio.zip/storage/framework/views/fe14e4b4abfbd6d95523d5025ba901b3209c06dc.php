<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <?php if( count($projects) <= 0): ?>
                <div class="alert alert-dark text-center col-md-6 mx-auto">
                    There is no projects yet.
                </div>
                <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-link btn-block mb-3">Create the first one</a>
            <?php else: ?>
                <div class="col-md-10 mx-auto">

                    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-dark border border-secondary mb-3">Add project</a>

                    <table class="table table-hover table-dark text-white">
                        <thead>
                            <tr>
                                <th class="text-center">Photo</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Description</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
    
                        <tbody>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('components.modal-project', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <tr class="text-center">
                                    <td>
                                        <img
                                            src="<?php echo e(Storage::url($project->images->first()->path)); ?>"
                                            alt=""
                                            width="100"
                                            height="100"
                                            class="rounded"
                                        >
                                    </td>

                                    <td>
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-link" data-toggle="modal" data-target="#exampleModal<?php echo e($project->id); ?>">
                                            <?php echo e($project->name); ?>

                                        </button>
                                    </td>

                                    <td>
                                        <p class="text-justify">
                                            <?php echo e($project->description); ?>

                                        </p>
                                    </td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-warning">Edit</a>
                                        <delete-project
                                            project="<?php echo e($project->id); ?>"
                                            project-name="<?php echo e($project->name); ?>"
                                        ></delete-project>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>        
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/projects/index.blade.php ENDPATH**/ ?>