<div class="modal fade" id="exampleModal<?php echo e($project->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content text-white myModal">
            
            <div id="carousel<?php echo e($project->id); ?>" class="carousel slide carousel-fade hover touch" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>" data-interval="3500">
                            <img 
                                src="<?php echo e(Storage::url($image->path)); ?>"
                                alt=""
                                class="d-block w-100 card-img-top projectImage"
                                height="300"
                            >                
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                    <a href="#carousel<?php echo e($project->id); ?>" class="carousel-control-prev" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        
                    </a>
                    <a href="#carousel<?php echo e($project->id); ?>" class="carousel-control-next" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        
                    </a>
                
            </div>
            
            <div class="modal-body">
                <h2 class="card-title text-center"><?php echo e($project->name); ?></h2>
                <p class="card-text" class="card-text text-justify">
                    <?php echo e($project->description); ?>

                </p>
                <p class="card-text">
                    <strong class="text-success">Technologies: </strong>
                    <?php $__currentLoopData = $project->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="text-sm border border-light rounded  text-center mr-1">
                            <small class="px-2"><?php echo e($technology->name); ?></small>
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php if($project->repository): ?>
                    <a href="<?php echo e($project->repository); ?>" class="flaticon-github mx-2" target="_blank"></a>
                <?php endif; ?>
                <?php if($project->url): ?>
                    <a href="<?php echo e($project->url); ?>" class="flaticon-external-link-symbol mx-2" target="_blank"></a>
                <?php endif; ?>
                <button type="button" class="btn btn-outline-light float-right" data-dismiss="modal" aria-label="Close">
                    Close
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/components/modal-project.blade.php ENDPATH**/ ?>