<?php echo e($slot); ?>

<?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>