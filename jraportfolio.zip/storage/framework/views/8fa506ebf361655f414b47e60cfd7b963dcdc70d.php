<div class="card bg-dark text-white border border-secondary myPhoto">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <?php for($i = 0, $image = $project->images; $i < sizeof($image); $i++): ?>
                <div class="carousel-item <?php echo e($i==0 ? 'active': ''); ?>">
                    <img src="<?php echo e(asset($image[$i]->path)); ?>" class="d-block w-100 card-img-top" alt="<?php echo e($image[$i]->path); ?>" height="200">
                </div>                    
            <?php endfor; ?>
        </div>
        <span class="sr-only">Previous</span>
        <span class="sr-only">Next</span>
    </div>
    
    <div class="card-body">
        <h4 class="card-title text-center"><?php echo e($project->name); ?></h4>
        <button type="button" class="btn btn-outline-secondary text-white btn-block">See project</button>
        
    </div>
</div><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/components/project.blade.php ENDPATH**/ ?>