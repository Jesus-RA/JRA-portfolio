<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>