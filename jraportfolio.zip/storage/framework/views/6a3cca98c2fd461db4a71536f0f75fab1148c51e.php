<div class="row myContact">
    <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8 mx-auto my-auto">
        <div class="card border border-dark myCard opaque" id="contactCard">
            <h2 class="text-center">Get in touch</h2>
            <form action="<?php echo e(route('contacts.store')); ?>" method="POST" id="formContact">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-6 mt-5">
                            <input type="text" name="name" placeholder="Name" class="myForm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errorForm <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="off" onkeyup="contactActive()" >
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block errorSpan" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
            
                        <div class="col-6 mt-5">
                            <input type="text" name="email" placeholder="e-mail" class="myForm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errorForm <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="email" onkeyup="contactActive()" >
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block errorSpan" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
            
                        <div class="col-12 my-auto">
                            <textarea name="message" id="message" rows="5" class="myForm myTextarea <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errorForm <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Leave a message" autocomplete="off" onkeyup="contactActive()" ></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block errorSpan">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-dark btn-block">Send</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>        
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
    <script>

        function contactActive(){
            event.target.classList.add('activeForm');
            
            const contactCard = document.getElementById('contactCard');
            contactCard.classList.remove('opaque');
            
            const inputs = document.querySelectorAll('.myForm');
            let inputsEmpty = 0;
            for(input of inputs){
                if(input.value.length === 0) {
                    inputsEmpty++
                }
            }
            // When inputs was emptied contact card comes back to be opaque
            if(inputsEmpty === 3){
                contactCard.classList.add('opaque');
                for(input of inputs){
                    input.classList.remove('activeForm');
                }
            }
            
        }

        
    </script>
<?php $__env->stopSection(); ?><?php /**PATH /Users/jesusra/Desktop/Laravel/myportfolio/resources/views/contact.blade.php ENDPATH**/ ?>